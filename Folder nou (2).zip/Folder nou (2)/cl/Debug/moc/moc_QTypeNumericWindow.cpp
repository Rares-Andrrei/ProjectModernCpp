/****************************************************************************
** Meta object code from reading C++ file 'QTypeNumericWindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../QTypeNumericWindow.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'QTypeNumericWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_QTypeNumericWindow_t {
    uint offsetsAndSizes[42];
    char stringdata0[19];
    char stringdata1[18];
    char stringdata2[1];
    char stringdata3[44];
    char stringdata4[12];
    char stringdata5[19];
    char stringdata6[19];
    char stringdata7[19];
    char stringdata8[19];
    char stringdata9[19];
    char stringdata10[19];
    char stringdata11[19];
    char stringdata12[19];
    char stringdata13[19];
    char stringdata14[19];
    char stringdata15[17];
    char stringdata16[18];
    char stringdata17[18];
    char stringdata18[18];
    char stringdata19[17];
    char stringdata20[25];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_QTypeNumericWindow_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_QTypeNumericWindow_t qt_meta_stringdata_QTypeNumericWindow = {
    {
        QT_MOC_LITERAL(0, 18),  // "QTypeNumericWindow"
        QT_MOC_LITERAL(19, 17),  // "sendOrderToParent"
        QT_MOC_LITERAL(37, 0),  // ""
        QT_MOC_LITERAL(38, 43),  // "std::queue<std::pair<Color::C..."
        QT_MOC_LITERAL(82, 11),  // "playerOrder"
        QT_MOC_LITERAL(94, 18),  // "on_Number0_clicked"
        QT_MOC_LITERAL(113, 18),  // "on_Number1_clicked"
        QT_MOC_LITERAL(132, 18),  // "on_Number2_clicked"
        QT_MOC_LITERAL(151, 18),  // "on_Number3_clicked"
        QT_MOC_LITERAL(170, 18),  // "on_Number4_clicked"
        QT_MOC_LITERAL(189, 18),  // "on_Number5_clicked"
        QT_MOC_LITERAL(208, 18),  // "on_Number6_clicked"
        QT_MOC_LITERAL(227, 18),  // "on_Number7_clicked"
        QT_MOC_LITERAL(246, 18),  // "on_Number8_clicked"
        QT_MOC_LITERAL(265, 18),  // "on_Number9_clicked"
        QT_MOC_LITERAL(284, 16),  // "on_Enter_clicked"
        QT_MOC_LITERAL(301, 17),  // "on_Delete_clicked"
        QT_MOC_LITERAL(319, 17),  // "on_Delete_pressed"
        QT_MOC_LITERAL(337, 17),  // "on_Delete_release"
        QT_MOC_LITERAL(355, 16),  // "on_Timer_Timeout"
        QT_MOC_LITERAL(372, 24)   // "on_TimeRemaining_Timeout"
    },
    "QTypeNumericWindow",
    "sendOrderToParent",
    "",
    "std::queue<std::pair<Color::ColorEnum,int>>",
    "playerOrder",
    "on_Number0_clicked",
    "on_Number1_clicked",
    "on_Number2_clicked",
    "on_Number3_clicked",
    "on_Number4_clicked",
    "on_Number5_clicked",
    "on_Number6_clicked",
    "on_Number7_clicked",
    "on_Number8_clicked",
    "on_Number9_clicked",
    "on_Enter_clicked",
    "on_Delete_clicked",
    "on_Delete_pressed",
    "on_Delete_release",
    "on_Timer_Timeout",
    "on_TimeRemaining_Timeout"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_QTypeNumericWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  116,    2, 0x06,    1 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       5,    0,  119,    2, 0x08,    3 /* Private */,
       6,    0,  120,    2, 0x08,    4 /* Private */,
       7,    0,  121,    2, 0x08,    5 /* Private */,
       8,    0,  122,    2, 0x08,    6 /* Private */,
       9,    0,  123,    2, 0x08,    7 /* Private */,
      10,    0,  124,    2, 0x08,    8 /* Private */,
      11,    0,  125,    2, 0x08,    9 /* Private */,
      12,    0,  126,    2, 0x08,   10 /* Private */,
      13,    0,  127,    2, 0x08,   11 /* Private */,
      14,    0,  128,    2, 0x08,   12 /* Private */,
      15,    0,  129,    2, 0x08,   13 /* Private */,
      16,    0,  130,    2, 0x08,   14 /* Private */,
      17,    0,  131,    2, 0x08,   15 /* Private */,
      18,    0,  132,    2, 0x08,   16 /* Private */,
      19,    0,  133,    2, 0x08,   17 /* Private */,
      20,    0,  134,    2, 0x08,   18 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject QTypeNumericWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_QTypeNumericWindow.offsetsAndSizes,
    qt_meta_data_QTypeNumericWindow,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_QTypeNumericWindow_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<QTypeNumericWindow, std::true_type>,
        // method 'sendOrderToParent'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const std::queue<std::pair<Color::ColorEnum,int>> &, std::false_type>,
        // method 'on_Number0_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Number1_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Number2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Number3_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Number4_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Number5_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Number6_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Number7_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Number8_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Number9_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Enter_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Delete_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Delete_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Delete_release'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Timer_Timeout'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_TimeRemaining_Timeout'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void QTypeNumericWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QTypeNumericWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->sendOrderToParent((*reinterpret_cast< std::add_pointer_t<std::queue<std::pair<Color::ColorEnum,int>>>>(_a[1]))); break;
        case 1: _t->on_Number0_clicked(); break;
        case 2: _t->on_Number1_clicked(); break;
        case 3: _t->on_Number2_clicked(); break;
        case 4: _t->on_Number3_clicked(); break;
        case 5: _t->on_Number4_clicked(); break;
        case 6: _t->on_Number5_clicked(); break;
        case 7: _t->on_Number6_clicked(); break;
        case 8: _t->on_Number7_clicked(); break;
        case 9: _t->on_Number8_clicked(); break;
        case 10: _t->on_Number9_clicked(); break;
        case 11: _t->on_Enter_clicked(); break;
        case 12: _t->on_Delete_clicked(); break;
        case 13: _t->on_Delete_pressed(); break;
        case 14: _t->on_Delete_release(); break;
        case 15: _t->on_Timer_Timeout(); break;
        case 16: _t->on_TimeRemaining_Timeout(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QTypeNumericWindow::*)(const std::queue<std::pair<Color::ColorEnum,int>> & );
            if (_t _q_method = &QTypeNumericWindow::sendOrderToParent; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject *QTypeNumericWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QTypeNumericWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QTypeNumericWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int QTypeNumericWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 17;
    }
    return _id;
}

// SIGNAL 0
void QTypeNumericWindow::sendOrderToParent(const std::queue<std::pair<Color::ColorEnum,int>> & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
