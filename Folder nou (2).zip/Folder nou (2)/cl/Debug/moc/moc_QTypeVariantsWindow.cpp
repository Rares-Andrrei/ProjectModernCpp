/****************************************************************************
** Meta object code from reading C++ file 'QTypeVariantsWindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../QTypeVariantsWindow.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'QTypeVariantsWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_QTypeVariantsWindow_t {
    uint offsetsAndSizes[20];
    char stringdata0[20];
    char stringdata1[20];
    char stringdata2[1];
    char stringdata3[20];
    char stringdata4[20];
    char stringdata5[20];
    char stringdata6[19];
    char stringdata7[17];
    char stringdata8[25];
    char stringdata9[26];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_QTypeVariantsWindow_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_QTypeVariantsWindow_t qt_meta_stringdata_QTypeVariantsWindow = {
    {
        QT_MOC_LITERAL(0, 19),  // "QTypeVariantsWindow"
        QT_MOC_LITERAL(20, 19),  // "on_Variant1_clicked"
        QT_MOC_LITERAL(40, 0),  // ""
        QT_MOC_LITERAL(41, 19),  // "on_Variant2_clicked"
        QT_MOC_LITERAL(61, 19),  // "on_Variant3_clicked"
        QT_MOC_LITERAL(81, 19),  // "on_Variant4_clicked"
        QT_MOC_LITERAL(101, 18),  // "on_Variant_clicked"
        QT_MOC_LITERAL(120, 16),  // "on_Enter_clicked"
        QT_MOC_LITERAL(137, 24),  // "on_TimeRemaining_Timeout"
        QT_MOC_LITERAL(162, 25)   // "onFiftyFiftyButtonClicked"
    },
    "QTypeVariantsWindow",
    "on_Variant1_clicked",
    "",
    "on_Variant2_clicked",
    "on_Variant3_clicked",
    "on_Variant4_clicked",
    "on_Variant_clicked",
    "on_Enter_clicked",
    "on_TimeRemaining_Timeout",
    "onFiftyFiftyButtonClicked"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_QTypeVariantsWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   62,    2, 0x08,    1 /* Private */,
       3,    0,   63,    2, 0x08,    2 /* Private */,
       4,    0,   64,    2, 0x08,    3 /* Private */,
       5,    0,   65,    2, 0x08,    4 /* Private */,
       6,    0,   66,    2, 0x08,    5 /* Private */,
       7,    0,   67,    2, 0x08,    6 /* Private */,
       8,    0,   68,    2, 0x08,    7 /* Private */,
       9,    0,   69,    2, 0x08,    8 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject QTypeVariantsWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_QTypeVariantsWindow.offsetsAndSizes,
    qt_meta_data_QTypeVariantsWindow,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_QTypeVariantsWindow_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<QTypeVariantsWindow, std::true_type>,
        // method 'on_Variant1_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Variant2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Variant3_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Variant4_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Variant_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Enter_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_TimeRemaining_Timeout'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onFiftyFiftyButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void QTypeVariantsWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QTypeVariantsWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_Variant1_clicked(); break;
        case 1: _t->on_Variant2_clicked(); break;
        case 2: _t->on_Variant3_clicked(); break;
        case 3: _t->on_Variant4_clicked(); break;
        case 4: _t->on_Variant_clicked(); break;
        case 5: _t->on_Enter_clicked(); break;
        case 6: _t->on_TimeRemaining_Timeout(); break;
        case 7: _t->onFiftyFiftyButtonClicked(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *QTypeVariantsWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QTypeVariantsWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QTypeVariantsWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int QTypeVariantsWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 8;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
