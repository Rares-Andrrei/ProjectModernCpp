/****************************************************************************
** Meta object code from reading C++ file 'Map.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../Map.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Map.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_Map_t {
    uint offsetsAndSizes[24];
    char stringdata0[4];
    char stringdata1[33];
    char stringdata2[1];
    char stringdata3[15];
    char stringdata4[15];
    char stringdata5[15];
    char stringdata6[15];
    char stringdata7[15];
    char stringdata8[15];
    char stringdata9[15];
    char stringdata10[15];
    char stringdata11[15];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_Map_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_Map_t qt_meta_stringdata_Map = {
    {
        QT_MOC_LITERAL(0, 3),  // "Map"
        QT_MOC_LITERAL(4, 32),  // "emitMapUpdatedChooseRegionsPhase"
        QT_MOC_LITERAL(37, 0),  // ""
        QT_MOC_LITERAL(38, 14),  // "onzona1Clicked"
        QT_MOC_LITERAL(53, 14),  // "onzona2Clicked"
        QT_MOC_LITERAL(68, 14),  // "onzona3Clicked"
        QT_MOC_LITERAL(83, 14),  // "onzona4Clicked"
        QT_MOC_LITERAL(98, 14),  // "onzona5Clicked"
        QT_MOC_LITERAL(113, 14),  // "onzona6Clicked"
        QT_MOC_LITERAL(128, 14),  // "onzona7Clicked"
        QT_MOC_LITERAL(143, 14),  // "onzona8Clicked"
        QT_MOC_LITERAL(158, 14)   // "onzona9Clicked"
    },
    "Map",
    "emitMapUpdatedChooseRegionsPhase",
    "",
    "onzona1Clicked",
    "onzona2Clicked",
    "onzona3Clicked",
    "onzona4Clicked",
    "onzona5Clicked",
    "onzona6Clicked",
    "onzona7Clicked",
    "onzona8Clicked",
    "onzona9Clicked"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_Map[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   74,    2, 0x06,    1 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       3,    0,   75,    2, 0x08,    2 /* Private */,
       4,    0,   76,    2, 0x08,    3 /* Private */,
       5,    0,   77,    2, 0x08,    4 /* Private */,
       6,    0,   78,    2, 0x08,    5 /* Private */,
       7,    0,   79,    2, 0x08,    6 /* Private */,
       8,    0,   80,    2, 0x08,    7 /* Private */,
       9,    0,   81,    2, 0x08,    8 /* Private */,
      10,    0,   82,    2, 0x08,    9 /* Private */,
      11,    0,   83,    2, 0x08,   10 /* Private */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject Map::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_Map.offsetsAndSizes,
    qt_meta_data_Map,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_Map_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Map, std::true_type>,
        // method 'emitMapUpdatedChooseRegionsPhase'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onzona1Clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onzona2Clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onzona3Clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onzona4Clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onzona5Clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onzona6Clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onzona7Clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onzona8Clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onzona9Clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void Map::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Map *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->emitMapUpdatedChooseRegionsPhase(); break;
        case 1: _t->onzona1Clicked(); break;
        case 2: _t->onzona2Clicked(); break;
        case 3: _t->onzona3Clicked(); break;
        case 4: _t->onzona4Clicked(); break;
        case 5: _t->onzona5Clicked(); break;
        case 6: _t->onzona6Clicked(); break;
        case 7: _t->onzona7Clicked(); break;
        case 8: _t->onzona8Clicked(); break;
        case 9: _t->onzona9Clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Map::*)();
            if (_t _q_method = &Map::emitMapUpdatedChooseRegionsPhase; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
    (void)_a;
}

const QMetaObject *Map::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Map::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Map.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int Map::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 10;
    }
    return _id;
}

// SIGNAL 0
void Map::emitMapUpdatedChooseRegionsPhase()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
