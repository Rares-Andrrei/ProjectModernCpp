/****************************************************************************
** Meta object code from reading C++ file 'MapForThreePlayers.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../MapForThreePlayers.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MapForThreePlayers.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_MapForThreePlayers_t {
    uint offsetsAndSizes[36];
    char stringdata0[19];
    char stringdata1[17];
    char stringdata2[1];
    char stringdata3[17];
    char stringdata4[17];
    char stringdata5[17];
    char stringdata6[17];
    char stringdata7[17];
    char stringdata8[17];
    char stringdata9[17];
    char stringdata10[17];
    char stringdata11[18];
    char stringdata12[18];
    char stringdata13[18];
    char stringdata14[18];
    char stringdata15[18];
    char stringdata16[18];
    char stringdata17[28];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_MapForThreePlayers_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_MapForThreePlayers_t qt_meta_stringdata_MapForThreePlayers = {
    {
        QT_MOC_LITERAL(0, 18),  // "MapForThreePlayers"
        QT_MOC_LITERAL(19, 16),  // "on_zona1_clicked"
        QT_MOC_LITERAL(36, 0),  // ""
        QT_MOC_LITERAL(37, 16),  // "on_zona2_clicked"
        QT_MOC_LITERAL(54, 16),  // "on_zona3_clicked"
        QT_MOC_LITERAL(71, 16),  // "on_zona4_clicked"
        QT_MOC_LITERAL(88, 16),  // "on_zona5_clicked"
        QT_MOC_LITERAL(105, 16),  // "on_zona6_clicked"
        QT_MOC_LITERAL(122, 16),  // "on_zona7_clicked"
        QT_MOC_LITERAL(139, 16),  // "on_zona8_clicked"
        QT_MOC_LITERAL(156, 16),  // "on_zona9_clicked"
        QT_MOC_LITERAL(173, 17),  // "on_zona10_clicked"
        QT_MOC_LITERAL(191, 17),  // "on_zona11_clicked"
        QT_MOC_LITERAL(209, 17),  // "on_zona12_clicked"
        QT_MOC_LITERAL(227, 17),  // "on_zona13_clicked"
        QT_MOC_LITERAL(245, 17),  // "on_zona14_clicked"
        QT_MOC_LITERAL(263, 17),  // "on_zona15_clicked"
        QT_MOC_LITERAL(281, 27)   // "on_CheckFinishState_Timeout"
    },
    "MapForThreePlayers",
    "on_zona1_clicked",
    "",
    "on_zona2_clicked",
    "on_zona3_clicked",
    "on_zona4_clicked",
    "on_zona5_clicked",
    "on_zona6_clicked",
    "on_zona7_clicked",
    "on_zona8_clicked",
    "on_zona9_clicked",
    "on_zona10_clicked",
    "on_zona11_clicked",
    "on_zona12_clicked",
    "on_zona13_clicked",
    "on_zona14_clicked",
    "on_zona15_clicked",
    "on_CheckFinishState_Timeout"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_MapForThreePlayers[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  110,    2, 0x08,    1 /* Private */,
       3,    0,  111,    2, 0x08,    2 /* Private */,
       4,    0,  112,    2, 0x08,    3 /* Private */,
       5,    0,  113,    2, 0x08,    4 /* Private */,
       6,    0,  114,    2, 0x08,    5 /* Private */,
       7,    0,  115,    2, 0x08,    6 /* Private */,
       8,    0,  116,    2, 0x08,    7 /* Private */,
       9,    0,  117,    2, 0x08,    8 /* Private */,
      10,    0,  118,    2, 0x08,    9 /* Private */,
      11,    0,  119,    2, 0x08,   10 /* Private */,
      12,    0,  120,    2, 0x08,   11 /* Private */,
      13,    0,  121,    2, 0x08,   12 /* Private */,
      14,    0,  122,    2, 0x08,   13 /* Private */,
      15,    0,  123,    2, 0x08,   14 /* Private */,
      16,    0,  124,    2, 0x08,   15 /* Private */,
      17,    0,  125,    2, 0x08,   16 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MapForThreePlayers::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MapForThreePlayers.offsetsAndSizes,
    qt_meta_data_MapForThreePlayers,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_MapForThreePlayers_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MapForThreePlayers, std::true_type>,
        // method 'on_zona1_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zona2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zona3_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zona4_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zona5_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zona6_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zona7_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zona8_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zona9_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zona10_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zona11_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zona12_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zona13_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zona14_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zona15_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_CheckFinishState_Timeout'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MapForThreePlayers::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MapForThreePlayers *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_zona1_clicked(); break;
        case 1: _t->on_zona2_clicked(); break;
        case 2: _t->on_zona3_clicked(); break;
        case 3: _t->on_zona4_clicked(); break;
        case 4: _t->on_zona5_clicked(); break;
        case 5: _t->on_zona6_clicked(); break;
        case 6: _t->on_zona7_clicked(); break;
        case 7: _t->on_zona8_clicked(); break;
        case 8: _t->on_zona9_clicked(); break;
        case 9: _t->on_zona10_clicked(); break;
        case 10: _t->on_zona11_clicked(); break;
        case 11: _t->on_zona12_clicked(); break;
        case 12: _t->on_zona13_clicked(); break;
        case 13: _t->on_zona14_clicked(); break;
        case 14: _t->on_zona15_clicked(); break;
        case 15: _t->on_CheckFinishState_Timeout(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *MapForThreePlayers::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MapForThreePlayers::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MapForThreePlayers.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MapForThreePlayers::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 16;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
