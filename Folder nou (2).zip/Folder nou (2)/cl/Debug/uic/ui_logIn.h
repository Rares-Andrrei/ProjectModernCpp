/********************************************************************************
** Form generated from reading UI file 'logIn.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_H
#define UI_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_logInClass
{
public:
    QWidget *centralWidget;
    QLineEdit *l_password;
    QLineEdit *l_username;
    QPushButton *enterButton;
    QFrame *frame;
    QCheckBox *showPasswordButton;
    QPushButton *goBackButton;

    void setupUi(QMainWindow *logInClass)
    {
        if (logInClass->objectName().isEmpty())
            logInClass->setObjectName("logInClass");
        logInClass->resize(450, 350);
        logInClass->setMinimumSize(QSize(450, 350));
        logInClass->setMaximumSize(QSize(450, 350));
        centralWidget = new QWidget(logInClass);
        centralWidget->setObjectName("centralWidget");
        l_password = new QLineEdit(centralWidget);
        l_password->setObjectName("l_password");
        l_password->setGeometry(QRect(90, 130, 261, 21));
        l_username = new QLineEdit(centralWidget);
        l_username->setObjectName("l_username");
        l_username->setGeometry(QRect(90, 90, 261, 21));
        enterButton = new QPushButton(centralWidget);
        enterButton->setObjectName("enterButton");
        enterButton->setGeometry(QRect(90, 260, 91, 31));
        QFont font;
        font.setFamilies({QString::fromUtf8("Calibri Light")});
        font.setPointSize(11);
        enterButton->setFont(font);
        enterButton->setCursor(QCursor(Qt::PointingHandCursor));
        frame = new QFrame(centralWidget);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(-10, -10, 461, 371));
        frame->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/background.png);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        showPasswordButton = new QCheckBox(centralWidget);
        showPasswordButton->setObjectName("showPasswordButton");
        showPasswordButton->setGeometry(QRect(90, 160, 111, 20));
        goBackButton = new QPushButton(centralWidget);
        goBackButton->setObjectName("goBackButton");
        goBackButton->setGeometry(QRect(260, 260, 91, 31));
        goBackButton->setFont(font);
        goBackButton->setCursor(QCursor(Qt::PointingHandCursor));
        logInClass->setCentralWidget(centralWidget);
        frame->raise();
        l_password->raise();
        l_username->raise();
        enterButton->raise();
        showPasswordButton->raise();
        goBackButton->raise();
        QWidget::setTabOrder(l_username, l_password);
        QWidget::setTabOrder(l_password, showPasswordButton);
        QWidget::setTabOrder(showPasswordButton, enterButton);
        QWidget::setTabOrder(enterButton, goBackButton);

        retranslateUi(logInClass);

        QMetaObject::connectSlotsByName(logInClass);
    } // setupUi

    void retranslateUi(QMainWindow *logInClass)
    {
        logInClass->setWindowTitle(QCoreApplication::translate("logInClass", "LOG IN", nullptr));
        enterButton->setText(QCoreApplication::translate("logInClass", "ENTER", nullptr));
        showPasswordButton->setText(QCoreApplication::translate("logInClass", "show password", nullptr));
        goBackButton->setText(QCoreApplication::translate("logInClass", "BACK", nullptr));
    } // retranslateUi

};

namespace Ui {
    class logInClass: public Ui_logInClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_H
