/********************************************************************************
** Form generated from reading UI file 'QTypeNumericWindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QTYPENUMERICWINDOW_H
#define UI_QTYPENUMERICWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QTypeNumericWindowClass
{
public:
    QWidget *centralWidget;
    QLineEdit *Answer;
    QSlider *TimeRemaining;
    QLabel *Question;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QPushButton *Number5;
    QPushButton *Number3;
    QPushButton *Number2;
    QPushButton *Number4;
    QPushButton *Number6;
    QPushButton *Number1;
    QPushButton *Number9;
    QPushButton *Number8;
    QPushButton *Delete;
    QPushButton *Number0;
    QPushButton *Enter;
    QPushButton *Number7;
    QFrame *frame;
    QPushButton *generateFourVariantsButton;
    QPushButton *generateAnswerButton;

    void setupUi(QMainWindow *QTypeNumericWindowClass)
    {
        if (QTypeNumericWindowClass->objectName().isEmpty())
            QTypeNumericWindowClass->setObjectName("QTypeNumericWindowClass");
        QTypeNumericWindowClass->resize(1300, 700);
        QTypeNumericWindowClass->setMinimumSize(QSize(1300, 700));
        QTypeNumericWindowClass->setMaximumSize(QSize(1300, 700));
        centralWidget = new QWidget(QTypeNumericWindowClass);
        centralWidget->setObjectName("centralWidget");
        Answer = new QLineEdit(centralWidget);
        Answer->setObjectName("Answer");
        Answer->setGeometry(QRect(360, 200, 421, 51));
        TimeRemaining = new QSlider(centralWidget);
        TimeRemaining->setObjectName("TimeRemaining");
        TimeRemaining->setGeometry(QRect(120, 150, 1051, 31));
        TimeRemaining->setOrientation(Qt::Horizontal);
        Question = new QLabel(centralWidget);
        Question->setObjectName("Question");
        Question->setGeometry(QRect(230, 30, 861, 91));
        Question->setStyleSheet(QString::fromUtf8("background-color: rgb(128, 162, 201);"));
        gridLayoutWidget = new QWidget(centralWidget);
        gridLayoutWidget->setObjectName("gridLayoutWidget");
        gridLayoutWidget->setGeometry(QRect(280, 310, 561, 281));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(0, 0, 0, 0);
        Number5 = new QPushButton(gridLayoutWidget);
        Number5->setObjectName("Number5");

        gridLayout->addWidget(Number5, 1, 1, 1, 1);

        Number3 = new QPushButton(gridLayoutWidget);
        Number3->setObjectName("Number3");

        gridLayout->addWidget(Number3, 0, 2, 1, 1);

        Number2 = new QPushButton(gridLayoutWidget);
        Number2->setObjectName("Number2");

        gridLayout->addWidget(Number2, 0, 1, 1, 1);

        Number4 = new QPushButton(gridLayoutWidget);
        Number4->setObjectName("Number4");

        gridLayout->addWidget(Number4, 1, 0, 1, 1);

        Number6 = new QPushButton(gridLayoutWidget);
        Number6->setObjectName("Number6");

        gridLayout->addWidget(Number6, 1, 2, 1, 1);

        Number1 = new QPushButton(gridLayoutWidget);
        Number1->setObjectName("Number1");

        gridLayout->addWidget(Number1, 0, 0, 1, 1);

        Number9 = new QPushButton(gridLayoutWidget);
        Number9->setObjectName("Number9");

        gridLayout->addWidget(Number9, 2, 2, 1, 1);

        Number8 = new QPushButton(gridLayoutWidget);
        Number8->setObjectName("Number8");

        gridLayout->addWidget(Number8, 2, 1, 1, 1);

        Delete = new QPushButton(gridLayoutWidget);
        Delete->setObjectName("Delete");

        gridLayout->addWidget(Delete, 3, 2, 1, 1);

        Number0 = new QPushButton(gridLayoutWidget);
        Number0->setObjectName("Number0");

        gridLayout->addWidget(Number0, 3, 1, 1, 1);

        Enter = new QPushButton(gridLayoutWidget);
        Enter->setObjectName("Enter");

        gridLayout->addWidget(Enter, 3, 0, 1, 1);

        Number7 = new QPushButton(gridLayoutWidget);
        Number7->setObjectName("Number7");

        gridLayout->addWidget(Number7, 2, 0, 1, 1);

        frame = new QFrame(centralWidget);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(-10, -10, 1311, 711));
        frame->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/backgroundQuestions.png);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        generateFourVariantsButton = new QPushButton(centralWidget);
        generateFourVariantsButton->setObjectName("generateFourVariantsButton");
        generateFourVariantsButton->setGeometry(QRect(960, 310, 111, 101));
        generateFourVariantsButton->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/generateFourAnswers.png);"));
        generateAnswerButton = new QPushButton(centralWidget);
        generateAnswerButton->setObjectName("generateAnswerButton");
        generateAnswerButton->setGeometry(QRect(960, 480, 111, 101));
        generateAnswerButton->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/generateAnAnswer.png);"));
        QTypeNumericWindowClass->setCentralWidget(centralWidget);
        frame->raise();
        Answer->raise();
        TimeRemaining->raise();
        Question->raise();
        gridLayoutWidget->raise();
        generateFourVariantsButton->raise();
        generateAnswerButton->raise();

        retranslateUi(QTypeNumericWindowClass);

        QMetaObject::connectSlotsByName(QTypeNumericWindowClass);
    } // setupUi

    void retranslateUi(QMainWindow *QTypeNumericWindowClass)
    {
        QTypeNumericWindowClass->setWindowTitle(QCoreApplication::translate("QTypeNumericWindowClass", "TIE-BREAKER", nullptr));
        Question->setText(QCoreApplication::translate("QTypeNumericWindowClass", "TextLabel", nullptr));
        Number5->setText(QCoreApplication::translate("QTypeNumericWindowClass", "5", nullptr));
        Number3->setText(QCoreApplication::translate("QTypeNumericWindowClass", "3", nullptr));
        Number2->setText(QCoreApplication::translate("QTypeNumericWindowClass", "2", nullptr));
        Number4->setText(QCoreApplication::translate("QTypeNumericWindowClass", "4", nullptr));
        Number6->setText(QCoreApplication::translate("QTypeNumericWindowClass", "6", nullptr));
        Number1->setText(QCoreApplication::translate("QTypeNumericWindowClass", "1", nullptr));
        Number9->setText(QCoreApplication::translate("QTypeNumericWindowClass", "9", nullptr));
        Number8->setText(QCoreApplication::translate("QTypeNumericWindowClass", "8", nullptr));
        Delete->setText(QCoreApplication::translate("QTypeNumericWindowClass", "delete", nullptr));
        Number0->setText(QCoreApplication::translate("QTypeNumericWindowClass", "0", nullptr));
        Enter->setText(QCoreApplication::translate("QTypeNumericWindowClass", "Enter", nullptr));
        Number7->setText(QCoreApplication::translate("QTypeNumericWindowClass", "7", nullptr));
        generateFourVariantsButton->setText(QString());
        generateAnswerButton->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class QTypeNumericWindowClass: public Ui_QTypeNumericWindowClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QTYPENUMERICWINDOW_H
