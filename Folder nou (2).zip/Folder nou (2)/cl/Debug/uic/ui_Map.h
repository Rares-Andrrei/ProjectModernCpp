/********************************************************************************
** Form generated from reading UI file 'Map.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAP_H
#define UI_MAP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MapClass
{
public:
    QWidget *centralWidget;
    QLabel *label;
    QPushButton *zona1;
    QPushButton *zona2;
    QPushButton *zona4;
    QPushButton *zona5;
    QPushButton *zona6;
    QPushButton *zona7;
    QPushButton *zona8;
    QPushButton *zona9;
    QPushButton *zona3;
    QLabel *player1Name;
    QLabel *player1Avatar;
    QLabel *player2Avatar;
    QLabel *player2Name;
    QLabel *player3Avatar;
    QLabel *player4Avatar;
    QLabel *player4Name;
    QLabel *player3Name;

    void setupUi(QMainWindow *MapClass)
    {
        if (MapClass->objectName().isEmpty())
            MapClass->setObjectName("MapClass");
        MapClass->resize(1920, 1080);
        MapClass->setMinimumSize(QSize(1920, 1080));
        MapClass->setMaximumSize(QSize(1920, 1080));
        MapClass->setCursor(QCursor(Qt::PointingHandCursor));
        MapClass->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/mapBackground.png);"));
        centralWidget = new QWidget(MapClass);
        centralWidget->setObjectName("centralWidget");
        label = new QLabel(centralWidget);
        label->setObjectName("label");
        label->setGeometry(QRect(-110, -68, 2101, 1181));
        label->setStyleSheet(QString::fromUtf8("background:transparent;"));
        label->setLineWidth(9);
        label->setPixmap(QPixmap(QString::fromUtf8("Ro.png")));
        label->setAlignment(Qt::AlignCenter);
        zona1 = new QPushButton(centralWidget);
        zona1->setObjectName("zona1");
        zona1->setGeometry(QRect(297, 68, 501, 371));
        zona1->setStyleSheet(QString::fromUtf8("background:transparent;\n"
"\n"
""));
        zona2 = new QPushButton(centralWidget);
        zona2->setObjectName("zona2");
        zona2->setGeometry(QRect(799, 67, 265, 371));
        zona2->setStyleSheet(QString::fromUtf8("background:transparent;\n"
""));
        zona4 = new QPushButton(centralWidget);
        zona4->setObjectName("zona4");
        zona4->setGeometry(QRect(297, 436, 501, 325));
        zona4->setStyleSheet(QString::fromUtf8("background:transparent;\n"
"\n"
""));
        zona5 = new QPushButton(centralWidget);
        zona5->setObjectName("zona5");
        zona5->setGeometry(QRect(798, 438, 265, 323));
        zona5->setStyleSheet(QString::fromUtf8("background:transparent;\n"
""));
        zona6 = new QPushButton(centralWidget);
        zona6->setObjectName("zona6");
        zona6->setGeometry(QRect(1060, 437, 523, 324));
        zona6->setStyleSheet(QString::fromUtf8("background:transparent;\n"
""));
        zona7 = new QPushButton(centralWidget);
        zona7->setObjectName("zona7");
        zona7->setGeometry(QRect(297, 758, 501, 223));
        zona7->setStyleSheet(QString::fromUtf8("background:transparent;\n"
"\n"
""));
        zona8 = new QPushButton(centralWidget);
        zona8->setObjectName("zona8");
        zona8->setGeometry(QRect(798, 760, 266, 221));
        zona8->setStyleSheet(QString::fromUtf8("background:transparent;\n"
""));
        zona9 = new QPushButton(centralWidget);
        zona9->setObjectName("zona9");
        zona9->setGeometry(QRect(1062, 760, 521, 221));
        zona9->setStyleSheet(QString::fromUtf8("background:transparent;\n"
""));
        zona3 = new QPushButton(centralWidget);
        zona3->setObjectName("zona3");
        zona3->setGeometry(QRect(1064, 66, 519, 371));
        zona3->setStyleSheet(QString::fromUtf8("background:transparent;\n"
""));
        player1Name = new QLabel(centralWidget);
        player1Name->setObjectName("player1Name");
        player1Name->setGeometry(QRect(50, 140, 131, 16));
        player1Avatar = new QLabel(centralWidget);
        player1Avatar->setObjectName("player1Avatar");
        player1Avatar->setGeometry(QRect(50, 20, 131, 111));
        player2Avatar = new QLabel(centralWidget);
        player2Avatar->setObjectName("player2Avatar");
        player2Avatar->setGeometry(QRect(1740, 20, 131, 111));
        player2Name = new QLabel(centralWidget);
        player2Name->setObjectName("player2Name");
        player2Name->setGeometry(QRect(1740, 140, 131, 16));
        player3Avatar = new QLabel(centralWidget);
        player3Avatar->setObjectName("player3Avatar");
        player3Avatar->setGeometry(QRect(50, 940, 131, 111));
        player4Avatar = new QLabel(centralWidget);
        player4Avatar->setObjectName("player4Avatar");
        player4Avatar->setGeometry(QRect(1750, 940, 131, 111));
        player4Name = new QLabel(centralWidget);
        player4Name->setObjectName("player4Name");
        player4Name->setGeometry(QRect(1750, 920, 131, 16));
        player3Name = new QLabel(centralWidget);
        player3Name->setObjectName("player3Name");
        player3Name->setGeometry(QRect(50, 920, 131, 16));
        MapClass->setCentralWidget(centralWidget);

        retranslateUi(MapClass);

        QMetaObject::connectSlotsByName(MapClass);
    } // setupUi

    void retranslateUi(QMainWindow *MapClass)
    {
        MapClass->setWindowTitle(QCoreApplication::translate("MapClass", "Map", nullptr));
        label->setText(QString());
        zona1->setText(QCoreApplication::translate("MapClass", "                                           zona1", nullptr));
        zona2->setText(QCoreApplication::translate("MapClass", "zona2", nullptr));
        zona4->setText(QCoreApplication::translate("MapClass", "zona4", nullptr));
        zona5->setText(QCoreApplication::translate("MapClass", "zona5", nullptr));
        zona6->setText(QCoreApplication::translate("MapClass", "zona6", nullptr));
        zona7->setText(QCoreApplication::translate("MapClass", "                                                                                                   zona7", nullptr));
        zona8->setText(QCoreApplication::translate("MapClass", "zona8", nullptr));
        zona9->setText(QCoreApplication::translate("MapClass", "zona9", nullptr));
        zona3->setText(QCoreApplication::translate("MapClass", "zona3", nullptr));
        player1Name->setText(QCoreApplication::translate("MapClass", "TextLabel", nullptr));
        player1Avatar->setText(QCoreApplication::translate("MapClass", "TextLabel", nullptr));
        player2Avatar->setText(QCoreApplication::translate("MapClass", "TextLabel", nullptr));
        player2Name->setText(QCoreApplication::translate("MapClass", "TextLabel", nullptr));
        player3Avatar->setText(QCoreApplication::translate("MapClass", "TextLabel", nullptr));
        player4Avatar->setText(QCoreApplication::translate("MapClass", "TextLabel", nullptr));
        player4Name->setText(QCoreApplication::translate("MapClass", "TextLabel", nullptr));
        player3Name->setText(QCoreApplication::translate("MapClass", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MapClass: public Ui_MapClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAP_H
