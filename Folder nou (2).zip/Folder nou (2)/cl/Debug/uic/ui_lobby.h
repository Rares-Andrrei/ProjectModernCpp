/********************************************************************************
** Form generated from reading UI file 'lobby.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOBBY_H
#define UI_LOBBY_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_lobbyClass
{
public:
    QWidget *centralWidget;
    QStackedWidget *lobbyGameModes;
    QWidget *page;
    QPushButton *gamesHistoryButton;
    QPushButton *twoPlayersButton;
    QPushButton *threePlayersButton;
    QPushButton *fourPlayersButton;
    QLabel *label;
    QFrame *frame;
    QWidget *page_2;
    QFrame *frame_2;
    QPushButton *cancelButton;
    QLabel *waitingForPlayersLabel;
    QLabel *loadingLabel;
    QLabel *catPicturesLabel;
    QLabel *label_2;
    QPushButton *nextButton;
    QPushButton *previousButton;
    QWidget *page_3;
    QLabel *playerNameLabel;
    QFrame *frame_3;
    QScrollArea *scrollArea;
    QWidget *scrollTable;
    QTableWidget *tableMatchHystory;
    QPushButton *backButton;

    void setupUi(QMainWindow *lobbyClass)
    {
        if (lobbyClass->objectName().isEmpty())
            lobbyClass->setObjectName("lobbyClass");
        lobbyClass->resize(600, 600);
        lobbyClass->setMinimumSize(QSize(600, 600));
        lobbyClass->setMaximumSize(QSize(600, 600));
        centralWidget = new QWidget(lobbyClass);
        centralWidget->setObjectName("centralWidget");
        lobbyGameModes = new QStackedWidget(centralWidget);
        lobbyGameModes->setObjectName("lobbyGameModes");
        lobbyGameModes->setGeometry(QRect(0, 0, 601, 641));
        lobbyGameModes->setStyleSheet(QString::fromUtf8(""));
        page = new QWidget();
        page->setObjectName("page");
        gamesHistoryButton = new QPushButton(page);
        gamesHistoryButton->setObjectName("gamesHistoryButton");
        gamesHistoryButton->setGeometry(QRect(20, 20, 111, 41));
        QFont font;
        font.setFamilies({QString::fromUtf8("Calibri Light")});
        font.setPointSize(11);
        gamesHistoryButton->setFont(font);
        gamesHistoryButton->setCursor(QCursor(Qt::PointingHandCursor));
        gamesHistoryButton->setMouseTracking(false);
        twoPlayersButton = new QPushButton(page);
        twoPlayersButton->setObjectName("twoPlayersButton");
        twoPlayersButton->setGeometry(QRect(130, 160, 361, 91));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Calibri Light")});
        font1.setPointSize(11);
        font1.setBold(false);
        font1.setItalic(true);
        font1.setUnderline(false);
        twoPlayersButton->setFont(font1);
        twoPlayersButton->setCursor(QCursor(Qt::PointingHandCursor));
        twoPlayersButton->setStyleSheet(QString::fromUtf8(""));
        threePlayersButton = new QPushButton(page);
        threePlayersButton->setObjectName("threePlayersButton");
        threePlayersButton->setGeometry(QRect(130, 280, 361, 91));
        threePlayersButton->setFont(font1);
        threePlayersButton->setCursor(QCursor(Qt::PointingHandCursor));
        threePlayersButton->setStyleSheet(QString::fromUtf8(""));
        fourPlayersButton = new QPushButton(page);
        fourPlayersButton->setObjectName("fourPlayersButton");
        fourPlayersButton->setGeometry(QRect(130, 410, 361, 91));
        fourPlayersButton->setFont(font1);
        fourPlayersButton->setCursor(QCursor(Qt::PointingHandCursor));
        fourPlayersButton->setLayoutDirection(Qt::LeftToRight);
        fourPlayersButton->setStyleSheet(QString::fromUtf8(""));
        label = new QLabel(page);
        label->setObjectName("label");
        label->setGeometry(QRect(20, 100, 211, 31));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Calibri Light")});
        font2.setPointSize(11);
        font2.setBold(true);
        label->setFont(font2);
        frame = new QFrame(page);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(-10, -10, 621, 621));
        frame->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/backgroundLobby.png);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        lobbyGameModes->addWidget(page);
        frame->raise();
        gamesHistoryButton->raise();
        twoPlayersButton->raise();
        threePlayersButton->raise();
        fourPlayersButton->raise();
        label->raise();
        page_2 = new QWidget();
        page_2->setObjectName("page_2");
        frame_2 = new QFrame(page_2);
        frame_2->setObjectName("frame_2");
        frame_2->setGeometry(QRect(-10, -10, 621, 621));
        frame_2->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/backgroundLobby.png);"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        cancelButton = new QPushButton(page_2);
        cancelButton->setObjectName("cancelButton");
        cancelButton->setGeometry(QRect(250, 500, 111, 41));
        QFont font3;
        font3.setFamilies({QString::fromUtf8("Calibri Light")});
        font3.setPointSize(10);
        cancelButton->setFont(font3);
        cancelButton->setCursor(QCursor(Qt::PointingHandCursor));
        waitingForPlayersLabel = new QLabel(page_2);
        waitingForPlayersLabel->setObjectName("waitingForPlayersLabel");
        waitingForPlayersLabel->setGeometry(QRect(20, 40, 131, 21));
        waitingForPlayersLabel->setFont(font2);
        loadingLabel = new QLabel(page_2);
        loadingLabel->setObjectName("loadingLabel");
        loadingLabel->setGeometry(QRect(150, 30, 51, 41));
        catPicturesLabel = new QLabel(page_2);
        catPicturesLabel->setObjectName("catPicturesLabel");
        catPicturesLabel->setGeometry(QRect(120, 90, 351, 341));
        label_2 = new QLabel(page_2);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(220, 460, 171, 31));
        label_2->setFont(font3);
        nextButton = new QPushButton(page_2);
        nextButton->setObjectName("nextButton");
        nextButton->setGeometry(QRect(440, 460, 75, 24));
        QFont font4;
        font4.setFamilies({QString::fromUtf8("Calibri Light")});
        nextButton->setFont(font4);
        nextButton->setCursor(QCursor(Qt::PointingHandCursor));
        previousButton = new QPushButton(page_2);
        previousButton->setObjectName("previousButton");
        previousButton->setGeometry(QRect(100, 460, 75, 24));
        previousButton->setFont(font4);
        previousButton->setCursor(QCursor(Qt::PointingHandCursor));
        lobbyGameModes->addWidget(page_2);
        page_3 = new QWidget();
        page_3->setObjectName("page_3");
        playerNameLabel = new QLabel(page_3);
        playerNameLabel->setObjectName("playerNameLabel");
        playerNameLabel->setGeometry(QRect(50, 40, 291, 41));
        playerNameLabel->setFont(font2);
        playerNameLabel->setStyleSheet(QString::fromUtf8("background-color: rgb(148, 188, 138);"));
        frame_3 = new QFrame(page_3);
        frame_3->setObjectName("frame_3");
        frame_3->setGeometry(QRect(-10, -10, 631, 651));
        frame_3->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/backgroundLobby.png);"));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        scrollArea = new QScrollArea(page_3);
        scrollArea->setObjectName("scrollArea");
        scrollArea->setGeometry(QRect(130, 100, 350, 351));
        scrollArea->setWidgetResizable(true);
        scrollTable = new QWidget();
        scrollTable->setObjectName("scrollTable");
        scrollTable->setGeometry(QRect(0, 0, 348, 349));
        tableMatchHystory = new QTableWidget(scrollTable);
        tableMatchHystory->setObjectName("tableMatchHystory");
        tableMatchHystory->setGeometry(QRect(0, 0, 350, 350));
        tableMatchHystory->setSortingEnabled(true);
        scrollArea->setWidget(scrollTable);
        backButton = new QPushButton(page_3);
        backButton->setObjectName("backButton");
        backButton->setGeometry(QRect(240, 500, 111, 41));
        backButton->setFont(font3);
        backButton->setCursor(QCursor(Qt::PointingHandCursor));
        lobbyGameModes->addWidget(page_3);
        frame_3->raise();
        playerNameLabel->raise();
        scrollArea->raise();
        backButton->raise();
        lobbyClass->setCentralWidget(centralWidget);

        retranslateUi(lobbyClass);

        lobbyGameModes->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(lobbyClass);
    } // setupUi

    void retranslateUi(QMainWindow *lobbyClass)
    {
        lobbyClass->setWindowTitle(QCoreApplication::translate("lobbyClass", "LOBBY", nullptr));
        gamesHistoryButton->setText(QCoreApplication::translate("lobbyClass", "Game History", nullptr));
        twoPlayersButton->setText(QCoreApplication::translate("lobbyClass", "2 PLAYERS", nullptr));
        threePlayersButton->setText(QCoreApplication::translate("lobbyClass", "3 PLAYERS", nullptr));
        fourPlayersButton->setText(QCoreApplication::translate("lobbyClass", "4 PLAYERS", nullptr));
        label->setText(QCoreApplication::translate("lobbyClass", "Choose a game mode to enter:", nullptr));
        cancelButton->setText(QCoreApplication::translate("lobbyClass", "CANCEL", nullptr));
        waitingForPlayersLabel->setText(QCoreApplication::translate("lobbyClass", "Waiting for players", nullptr));
        loadingLabel->setText(QString());
        catPicturesLabel->setText(QString());
        label_2->setText(QCoreApplication::translate("lobbyClass", "look at this cats while waiting!", nullptr));
        nextButton->setText(QCoreApplication::translate("lobbyClass", "NEXT", nullptr));
        previousButton->setText(QCoreApplication::translate("lobbyClass", "PREVIOUS", nullptr));
        playerNameLabel->setText(QCoreApplication::translate("lobbyClass", "TextLabel", nullptr));
        backButton->setText(QCoreApplication::translate("lobbyClass", "BACK", nullptr));
    } // retranslateUi

};

namespace Ui {
    class lobbyClass: public Ui_lobbyClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOBBY_H
