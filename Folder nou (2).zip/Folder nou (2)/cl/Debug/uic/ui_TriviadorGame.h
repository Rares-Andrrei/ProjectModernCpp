/********************************************************************************
** Form generated from reading UI file 'TriviadorGame.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRIVIADORGAME_H
#define UI_TRIVIADORGAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TriviadorGameClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *TriviadorGameClass)
    {
        if (TriviadorGameClass->objectName().isEmpty())
            TriviadorGameClass->setObjectName("TriviadorGameClass");
        TriviadorGameClass->resize(600, 400);
        menuBar = new QMenuBar(TriviadorGameClass);
        menuBar->setObjectName("menuBar");
        TriviadorGameClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(TriviadorGameClass);
        mainToolBar->setObjectName("mainToolBar");
        TriviadorGameClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(TriviadorGameClass);
        centralWidget->setObjectName("centralWidget");
        TriviadorGameClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(TriviadorGameClass);
        statusBar->setObjectName("statusBar");
        TriviadorGameClass->setStatusBar(statusBar);

        retranslateUi(TriviadorGameClass);

        QMetaObject::connectSlotsByName(TriviadorGameClass);
    } // setupUi

    void retranslateUi(QMainWindow *TriviadorGameClass)
    {
        TriviadorGameClass->setWindowTitle(QCoreApplication::translate("TriviadorGameClass", "TriviadorGame", nullptr));
    } // retranslateUi

};

namespace Ui {
    class TriviadorGameClass: public Ui_TriviadorGameClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRIVIADORGAME_H
