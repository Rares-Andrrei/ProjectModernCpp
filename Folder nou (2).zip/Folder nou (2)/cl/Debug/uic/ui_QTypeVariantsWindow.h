/********************************************************************************
** Form generated from reading UI file 'QTypeVariantsWindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QTYPEVARIANTSWINDOW_H
#define UI_QTYPEVARIANTSWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QTypeVariantsWindowClass
{
public:
    QWidget *centralWidget;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QPushButton *VariantC;
    QPushButton *VariantB;
    QPushButton *VariantD;
    QPushButton *VariantA;
    QLabel *Question;
    QPushButton *Enter;
    QSlider *TimeSlider;
    QPushButton *fiftyFiftyAdvantajeButton;
    QFrame *frame;

    void setupUi(QMainWindow *QTypeVariantsWindowClass)
    {
        if (QTypeVariantsWindowClass->objectName().isEmpty())
            QTypeVariantsWindowClass->setObjectName("QTypeVariantsWindowClass");
        QTypeVariantsWindowClass->resize(1300, 700);
        QTypeVariantsWindowClass->setMinimumSize(QSize(1300, 700));
        QTypeVariantsWindowClass->setMaximumSize(QSize(1300, 700));
        centralWidget = new QWidget(QTypeVariantsWindowClass);
        centralWidget->setObjectName("centralWidget");
        gridLayoutWidget = new QWidget(centralWidget);
        gridLayoutWidget->setObjectName("gridLayoutWidget");
        gridLayoutWidget->setGeometry(QRect(100, 250, 981, 321));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(0, 0, 0, 0);
        VariantC = new QPushButton(gridLayoutWidget);
        VariantC->setObjectName("VariantC");
        VariantC->setCursor(QCursor(Qt::PointingHandCursor));
        VariantC->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(VariantC, 1, 0, 1, 1);

        VariantB = new QPushButton(gridLayoutWidget);
        VariantB->setObjectName("VariantB");
        VariantB->setCursor(QCursor(Qt::PointingHandCursor));
        VariantB->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(VariantB, 0, 1, 1, 1);

        VariantD = new QPushButton(gridLayoutWidget);
        VariantD->setObjectName("VariantD");
        VariantD->setCursor(QCursor(Qt::PointingHandCursor));
        VariantD->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(VariantD, 1, 1, 1, 1);

        VariantA = new QPushButton(gridLayoutWidget);
        VariantA->setObjectName("VariantA");
        VariantA->setCursor(QCursor(Qt::PointingHandCursor));
        VariantA->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(VariantA, 0, 0, 1, 1);

        Question = new QLabel(centralWidget);
        Question->setObjectName("Question");
        Question->setGeometry(QRect(40, 30, 1101, 111));
        Question->setStyleSheet(QString::fromUtf8("background-color: rgb(128, 162, 201);"));
        Enter = new QPushButton(centralWidget);
        Enter->setObjectName("Enter");
        Enter->setGeometry(QRect(510, 610, 171, 51));
        QFont font;
        font.setFamilies({QString::fromUtf8("Calibri Light")});
        font.setPointSize(11);
        Enter->setFont(font);
        Enter->setCursor(QCursor(Qt::PointingHandCursor));
        TimeSlider = new QSlider(centralWidget);
        TimeSlider->setObjectName("TimeSlider");
        TimeSlider->setGeometry(QRect(40, 160, 1101, 22));
        TimeSlider->setStyleSheet(QString::fromUtf8(""));
        TimeSlider->setOrientation(Qt::Horizontal);
        fiftyFiftyAdvantajeButton = new QPushButton(centralWidget);
        fiftyFiftyAdvantajeButton->setObjectName("fiftyFiftyAdvantajeButton");
        fiftyFiftyAdvantajeButton->setGeometry(QRect(1140, 330, 111, 101));
        fiftyFiftyAdvantajeButton->setCursor(QCursor(Qt::PointingHandCursor));
        fiftyFiftyAdvantajeButton->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/fiftyFifty.png);"));
        frame = new QFrame(centralWidget);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(-1, -1, 1311, 711));
        frame->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/backgroundQuestions.png);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        QTypeVariantsWindowClass->setCentralWidget(centralWidget);
        frame->raise();
        gridLayoutWidget->raise();
        Question->raise();
        Enter->raise();
        TimeSlider->raise();
        fiftyFiftyAdvantajeButton->raise();

        retranslateUi(QTypeVariantsWindowClass);

        QMetaObject::connectSlotsByName(QTypeVariantsWindowClass);
    } // setupUi

    void retranslateUi(QMainWindow *QTypeVariantsWindowClass)
    {
        QTypeVariantsWindowClass->setWindowTitle(QCoreApplication::translate("QTypeVariantsWindowClass", "QUESTION", nullptr));
        VariantC->setText(QCoreApplication::translate("QTypeVariantsWindowClass", "C", nullptr));
        VariantB->setText(QCoreApplication::translate("QTypeVariantsWindowClass", "B", nullptr));
        VariantD->setText(QCoreApplication::translate("QTypeVariantsWindowClass", "D", nullptr));
        VariantA->setText(QCoreApplication::translate("QTypeVariantsWindowClass", "A", nullptr));
        Question->setText(QCoreApplication::translate("QTypeVariantsWindowClass", "TextLabel", nullptr));
        Enter->setText(QCoreApplication::translate("QTypeVariantsWindowClass", "Enter", nullptr));
        fiftyFiftyAdvantajeButton->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class QTypeVariantsWindowClass: public Ui_QTypeVariantsWindowClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QTYPEVARIANTSWINDOW_H
