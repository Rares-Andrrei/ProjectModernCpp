/********************************************************************************
** Form generated from reading UI file 'signUp.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SIGNUP_H
#define UI_SIGNUP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_signUpClass
{
public:
    QWidget *centralWidget;
    QPushButton *enterButton;
    QLineEdit *s_name;
    QLineEdit *s_password;
    QLineEdit *s_username;
    QLineEdit *s_confirmPassword;
    QFrame *frame;
    QPushButton *goBackButton;
    QCheckBox *showPasswordButton;
    QCheckBox *showConfirmedPasswordButton;

    void setupUi(QMainWindow *signUpClass)
    {
        if (signUpClass->objectName().isEmpty())
            signUpClass->setObjectName("signUpClass");
        signUpClass->resize(450, 350);
        signUpClass->setMinimumSize(QSize(450, 350));
        signUpClass->setMaximumSize(QSize(450, 350));
        centralWidget = new QWidget(signUpClass);
        centralWidget->setObjectName("centralWidget");
        enterButton = new QPushButton(centralWidget);
        enterButton->setObjectName("enterButton");
        enterButton->setGeometry(QRect(90, 260, 91, 31));
        QFont font;
        font.setFamilies({QString::fromUtf8("Calibri Light")});
        font.setPointSize(11);
        enterButton->setFont(font);
        enterButton->setCursor(QCursor(Qt::PointingHandCursor));
        enterButton->setAutoFillBackground(false);
        s_name = new QLineEdit(centralWidget);
        s_name->setObjectName("s_name");
        s_name->setGeometry(QRect(90, 40, 261, 21));
        s_password = new QLineEdit(centralWidget);
        s_password->setObjectName("s_password");
        s_password->setGeometry(QRect(90, 120, 261, 21));
        s_password->setEchoMode(QLineEdit::Normal);
        s_username = new QLineEdit(centralWidget);
        s_username->setObjectName("s_username");
        s_username->setGeometry(QRect(90, 80, 261, 21));
        s_confirmPassword = new QLineEdit(centralWidget);
        s_confirmPassword->setObjectName("s_confirmPassword");
        s_confirmPassword->setGeometry(QRect(90, 180, 261, 21));
        s_confirmPassword->setEchoMode(QLineEdit::Normal);
        frame = new QFrame(centralWidget);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(-10, -10, 461, 371));
        frame->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/background.png);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        goBackButton = new QPushButton(centralWidget);
        goBackButton->setObjectName("goBackButton");
        goBackButton->setGeometry(QRect(260, 260, 91, 31));
        goBackButton->setFont(font);
        goBackButton->setCursor(QCursor(Qt::PointingHandCursor));
        showPasswordButton = new QCheckBox(centralWidget);
        showPasswordButton->setObjectName("showPasswordButton");
        showPasswordButton->setGeometry(QRect(90, 150, 111, 20));
        showConfirmedPasswordButton = new QCheckBox(centralWidget);
        showConfirmedPasswordButton->setObjectName("showConfirmedPasswordButton");
        showConfirmedPasswordButton->setGeometry(QRect(90, 210, 111, 20));
        signUpClass->setCentralWidget(centralWidget);
        frame->raise();
        s_name->raise();
        s_password->raise();
        s_username->raise();
        s_confirmPassword->raise();
        enterButton->raise();
        goBackButton->raise();
        showPasswordButton->raise();
        showConfirmedPasswordButton->raise();
        QWidget::setTabOrder(s_name, s_username);
        QWidget::setTabOrder(s_username, s_password);
        QWidget::setTabOrder(s_password, s_confirmPassword);
        QWidget::setTabOrder(s_confirmPassword, enterButton);
        QWidget::setTabOrder(enterButton, goBackButton);

        retranslateUi(signUpClass);

        QMetaObject::connectSlotsByName(signUpClass);
    } // setupUi

    void retranslateUi(QMainWindow *signUpClass)
    {
        signUpClass->setWindowTitle(QCoreApplication::translate("signUpClass", "SIGN UP", nullptr));
        enterButton->setText(QCoreApplication::translate("signUpClass", "ENTER", nullptr));
        goBackButton->setText(QCoreApplication::translate("signUpClass", "BACK", nullptr));
        showPasswordButton->setText(QCoreApplication::translate("signUpClass", "show password", nullptr));
        showConfirmedPasswordButton->setText(QCoreApplication::translate("signUpClass", "show password", nullptr));
    } // retranslateUi

};

namespace Ui {
    class signUpClass: public Ui_signUpClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SIGNUP_H
