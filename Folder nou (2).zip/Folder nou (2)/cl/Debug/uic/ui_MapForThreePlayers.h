/********************************************************************************
** Form generated from reading UI file 'MapForThreePlayers.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAPFORTHREEPLAYERS_H
#define UI_MAPFORTHREEPLAYERS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MapForThreePlayersClass
{
public:
    QWidget *centralWidget;
    QLabel *label;
    QFrame *line;
    QFrame *line_2;
    QFrame *line_3;
    QFrame *line_4;
    QFrame *line_5;
    QFrame *line_6;
    QPushButton *zona1;
    QPushButton *zona2;
    QPushButton *zona3;
    QPushButton *zona4;
    QPushButton *zona5;
    QPushButton *zona6;
    QPushButton *zona7;
    QPushButton *zona8;
    QPushButton *zona9;
    QPushButton *zona10;
    QPushButton *zona11;
    QPushButton *zona12;
    QPushButton *zona13;
    QPushButton *zona14;
    QPushButton *zona15;

    void setupUi(QMainWindow *MapForThreePlayersClass)
    {
        if (MapForThreePlayersClass->objectName().isEmpty())
            MapForThreePlayersClass->setObjectName("MapForThreePlayersClass");
        MapForThreePlayersClass->resize(1920, 1080);
        MapForThreePlayersClass->setMinimumSize(QSize(1920, 1080));
        centralWidget = new QWidget(MapForThreePlayersClass);
        centralWidget->setObjectName("centralWidget");
        centralWidget->setStyleSheet(QString::fromUtf8("background-image:url(:/gui/mapBackground.png)"));
        label = new QLabel(centralWidget);
        label->setObjectName("label");
        label->setGeometry(QRect(0, 0, 1920, 1080));
        label->setMinimumSize(QSize(1920, 1080));
        label->setMaximumSize(QSize(1920, 1080));
        label->setStyleSheet(QString::fromUtf8("background-image: transparent\n"
""));
        label->setPixmap(QPixmap(QString::fromUtf8("Ro.png")));
        label->setAlignment(Qt::AlignCenter);
        line = new QFrame(centralWidget);
        line->setObjectName("line");
        line->setGeometry(QRect(540, 290, 791, 16));
        line->setStyleSheet(QString::fromUtf8("background:transparent"));
        line->setFrameShadow(QFrame::Plain);
        line->setLineWidth(2);
        line->setMidLineWidth(10);
        line->setFrameShape(QFrame::HLine);
        line_2 = new QFrame(centralWidget);
        line_2->setObjectName("line_2");
        line_2->setGeometry(QRect(440, 450, 951, 16));
        line_2->setStyleSheet(QString::fromUtf8("background:transparent\n"
""));
        line_2->setFrameShadow(QFrame::Plain);
        line_2->setLineWidth(2);
        line_2->setMidLineWidth(10);
        line_2->setFrameShape(QFrame::HLine);
        line_3 = new QFrame(centralWidget);
        line_3->setObjectName("line_3");
        line_3->setGeometry(QRect(470, 670, 1131, 20));
        line_3->setStyleSheet(QString::fromUtf8("background:transparent"));
        line_3->setFrameShadow(QFrame::Plain);
        line_3->setLineWidth(2);
        line_3->setMidLineWidth(10);
        line_3->setFrameShape(QFrame::HLine);
        line_4 = new QFrame(centralWidget);
        line_4->setObjectName("line_4");
        line_4->setGeometry(QRect(610, 830, 851, 16));
        line_4->setStyleSheet(QString::fromUtf8("background:transparent"));
        line_4->setFrameShadow(QFrame::Plain);
        line_4->setLineWidth(2);
        line_4->setMidLineWidth(10);
        line_4->setFrameShape(QFrame::HLine);
        line_5 = new QFrame(centralWidget);
        line_5->setObjectName("line_5");
        line_5->setGeometry(QRect(800, 140, 20, 821));
        line_5->setStyleSheet(QString::fromUtf8("background:transparent"));
        line_5->setFrameShadow(QFrame::Plain);
        line_5->setLineWidth(2);
        line_5->setMidLineWidth(10);
        line_5->setFrameShape(QFrame::VLine);
        line_6 = new QFrame(centralWidget);
        line_6->setObjectName("line_6");
        line_6->setGeometry(QRect(1043, 150, 20, 821));
        line_6->setStyleSheet(QString::fromUtf8("background:transparent"));
        line_6->setFrameShadow(QFrame::Plain);
        line_6->setLineWidth(2);
        line_6->setMidLineWidth(10);
        line_6->setFrameShape(QFrame::VLine);
        zona1 = new QPushButton(centralWidget);
        zona1->setObjectName("zona1");
        zona1->setGeometry(QRect(538, 110, 271, 188));
        zona1->setStyleSheet(QString::fromUtf8("background:transparent"));
        zona2 = new QPushButton(centralWidget);
        zona2->setObjectName("zona2");
        zona2->setGeometry(QRect(810, 130, 242, 168));
        zona2->setStyleSheet(QString::fromUtf8("background:transparent"));
        zona3 = new QPushButton(centralWidget);
        zona3->setObjectName("zona3");
        zona3->setGeometry(QRect(1053, 80, 279, 218));
        zona3->setStyleSheet(QString::fromUtf8("background:transparent"));
        zona4 = new QPushButton(centralWidget);
        zona4->setObjectName("zona4");
        zona4->setGeometry(QRect(430, 298, 381, 161));
        zona4->setStyleSheet(QString::fromUtf8("background:transparent"));
        zona5 = new QPushButton(centralWidget);
        zona5->setObjectName("zona5");
        zona5->setGeometry(QRect(810, 297, 243, 161));
        zona5->setStyleSheet(QString::fromUtf8("background:transparent"));
        zona6 = new QPushButton(centralWidget);
        zona6->setObjectName("zona6");
        zona6->setGeometry(QRect(1053, 298, 351, 161));
        zona6->setStyleSheet(QString::fromUtf8("background:transparent"));
        zona7 = new QPushButton(centralWidget);
        zona7->setObjectName("zona7");
        zona7->setGeometry(QRect(310, 458, 500, 222));
        zona7->setStyleSheet(QString::fromUtf8("background:transparent"));
        zona8 = new QPushButton(centralWidget);
        zona8->setObjectName("zona8");
        zona8->setGeometry(QRect(802, 458, 251, 222));
        zona8->setMinimumSize(QSize(251, 0));
        zona8->setStyleSheet(QString::fromUtf8("background:transparent\n"
""));
        zona9 = new QPushButton(centralWidget);
        zona9->setObjectName("zona9");
        zona9->setGeometry(QRect(1053, 459, 557, 221));
        zona9->setStyleSheet(QString::fromUtf8("background:transparent"));
        zona10 = new QPushButton(centralWidget);
        zona10->setObjectName("zona10");
        zona10->setGeometry(QRect(450, 680, 361, 158));
        zona10->setStyleSheet(QString::fromUtf8("background:transparent"));
        zona11 = new QPushButton(centralWidget);
        zona11->setObjectName("zona11");
        zona11->setGeometry(QRect(810, 681, 243, 157));
        zona11->setStyleSheet(QString::fromUtf8("background:transparent"));
        zona12 = new QPushButton(centralWidget);
        zona12->setObjectName("zona12");
        zona12->setGeometry(QRect(1054, 680, 551, 161));
        zona12->setStyleSheet(QString::fromUtf8("background:transparent"));
        zona13 = new QPushButton(centralWidget);
        zona13->setObjectName("zona13");
        zona13->setGeometry(QRect(600, 838, 210, 123));
        zona13->setStyleSheet(QString::fromUtf8("background:transparent"));
        zona14 = new QPushButton(centralWidget);
        zona14->setObjectName("zona14");
        zona14->setGeometry(QRect(810, 838, 243, 153));
        zona14->setStyleSheet(QString::fromUtf8("background:transparent"));
        zona15 = new QPushButton(centralWidget);
        zona15->setObjectName("zona15");
        zona15->setGeometry(QRect(1053, 838, 451, 139));
        zona15->setStyleSheet(QString::fromUtf8("background:transparent"));
        MapForThreePlayersClass->setCentralWidget(centralWidget);

        retranslateUi(MapForThreePlayersClass);

        QMetaObject::connectSlotsByName(MapForThreePlayersClass);
    } // setupUi

    void retranslateUi(QMainWindow *MapForThreePlayersClass)
    {
        MapForThreePlayersClass->setWindowTitle(QCoreApplication::translate("MapForThreePlayersClass", "MapForThreePlayers", nullptr));
        label->setText(QString());
        zona1->setText(QCoreApplication::translate("MapForThreePlayersClass", "zona1", nullptr));
        zona2->setText(QCoreApplication::translate("MapForThreePlayersClass", "zona2", nullptr));
        zona3->setText(QCoreApplication::translate("MapForThreePlayersClass", "zona3", nullptr));
        zona4->setText(QCoreApplication::translate("MapForThreePlayersClass", "zona4", nullptr));
        zona5->setText(QCoreApplication::translate("MapForThreePlayersClass", "zona5", nullptr));
        zona6->setText(QCoreApplication::translate("MapForThreePlayersClass", "zona6", nullptr));
        zona7->setText(QCoreApplication::translate("MapForThreePlayersClass", "zona7", nullptr));
        zona8->setText(QCoreApplication::translate("MapForThreePlayersClass", "zona8", nullptr));
        zona9->setText(QCoreApplication::translate("MapForThreePlayersClass", "zona9", nullptr));
        zona10->setText(QCoreApplication::translate("MapForThreePlayersClass", "zona10", nullptr));
        zona11->setText(QCoreApplication::translate("MapForThreePlayersClass", "zona11", nullptr));
        zona12->setText(QCoreApplication::translate("MapForThreePlayersClass", "zona12", nullptr));
        zona13->setText(QCoreApplication::translate("MapForThreePlayersClass", "zona13", nullptr));
        zona14->setText(QCoreApplication::translate("MapForThreePlayersClass", "zona14", nullptr));
        zona15->setText(QCoreApplication::translate("MapForThreePlayersClass", "zona15", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MapForThreePlayersClass: public Ui_MapForThreePlayersClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAPFORTHREEPLAYERS_H
