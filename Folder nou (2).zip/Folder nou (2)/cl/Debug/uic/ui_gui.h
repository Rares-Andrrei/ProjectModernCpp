/********************************************************************************
** Form generated from reading UI file 'gui.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUI_H
#define UI_GUI_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_guiClass
{
public:
    QWidget *centralWidget;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QPushButton *playButton;
    QFrame *frame;
    QWidget *page_2;
    QPushButton *loginButton;
    QPushButton *signUpButton;
    QFrame *frame_2;

    void setupUi(QMainWindow *guiClass)
    {
        if (guiClass->objectName().isEmpty())
            guiClass->setObjectName("guiClass");
        guiClass->resize(600, 600);
        guiClass->setMinimumSize(QSize(600, 600));
        guiClass->setMaximumSize(QSize(600, 600));
        centralWidget = new QWidget(guiClass);
        centralWidget->setObjectName("centralWidget");
        stackedWidget = new QStackedWidget(centralWidget);
        stackedWidget->setObjectName("stackedWidget");
        stackedWidget->setGeometry(QRect(-10, 0, 611, 611));
        page = new QWidget();
        page->setObjectName("page");
        playButton = new QPushButton(page);
        playButton->setObjectName("playButton");
        playButton->setGeometry(QRect(250, 350, 111, 41));
        QFont font;
        font.setFamilies({QString::fromUtf8("Calibri Light")});
        font.setPointSize(18);
        font.setBold(false);
        playButton->setFont(font);
        playButton->setCursor(QCursor(Qt::PointingHandCursor));
        playButton->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/background.png);"));
        frame = new QFrame(page);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(9, -1, 611, 611));
        frame->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/startMeniu.png);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        stackedWidget->addWidget(page);
        frame->raise();
        playButton->raise();
        page_2 = new QWidget();
        page_2->setObjectName("page_2");
        loginButton = new QPushButton(page_2);
        loginButton->setObjectName("loginButton");
        loginButton->setGeometry(QRect(260, 280, 111, 41));
        loginButton->setFont(font);
        loginButton->setCursor(QCursor(Qt::PointingHandCursor));
        loginButton->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/background.png);"));
        signUpButton = new QPushButton(page_2);
        signUpButton->setObjectName("signUpButton");
        signUpButton->setGeometry(QRect(260, 350, 111, 41));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Calibri Light")});
        font1.setPointSize(18);
        signUpButton->setFont(font1);
        signUpButton->setCursor(QCursor(Qt::PointingHandCursor));
        signUpButton->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/background.png);"));
        frame_2 = new QFrame(page_2);
        frame_2->setObjectName("frame_2");
        frame_2->setGeometry(QRect(9, -1, 611, 611));
        frame_2->setStyleSheet(QString::fromUtf8("background-image: url(:/gui/startMeniu.png);"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        stackedWidget->addWidget(page_2);
        frame_2->raise();
        loginButton->raise();
        signUpButton->raise();
        guiClass->setCentralWidget(centralWidget);

        retranslateUi(guiClass);

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(guiClass);
    } // setupUi

    void retranslateUi(QMainWindow *guiClass)
    {
        guiClass->setWindowTitle(QCoreApplication::translate("guiClass", "TRIVIADOR", nullptr));
        playButton->setText(QCoreApplication::translate("guiClass", "PLAY", nullptr));
        loginButton->setText(QCoreApplication::translate("guiClass", "LOG IN", nullptr));
        signUpButton->setText(QCoreApplication::translate("guiClass", "SIGN UP", nullptr));
    } // retranslateUi

};

namespace Ui {
    class guiClass: public Ui_guiClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUI_H
