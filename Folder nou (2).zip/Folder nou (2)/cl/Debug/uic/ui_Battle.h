/********************************************************************************
** Form generated from reading UI file 'Battle.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BATTLE_H
#define UI_BATTLE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_BattleClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *BattleClass)
    {
        if (BattleClass->objectName().isEmpty())
            BattleClass->setObjectName("BattleClass");
        BattleClass->resize(600, 400);
        menuBar = new QMenuBar(BattleClass);
        menuBar->setObjectName("menuBar");
        BattleClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(BattleClass);
        mainToolBar->setObjectName("mainToolBar");
        BattleClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(BattleClass);
        centralWidget->setObjectName("centralWidget");
        BattleClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(BattleClass);
        statusBar->setObjectName("statusBar");
        BattleClass->setStatusBar(statusBar);

        retranslateUi(BattleClass);

        QMetaObject::connectSlotsByName(BattleClass);
    } // setupUi

    void retranslateUi(QMainWindow *BattleClass)
    {
        BattleClass->setWindowTitle(QCoreApplication::translate("BattleClass", "Battle", nullptr));
    } // retranslateUi

};

namespace Ui {
    class BattleClass: public Ui_BattleClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BATTLE_H
